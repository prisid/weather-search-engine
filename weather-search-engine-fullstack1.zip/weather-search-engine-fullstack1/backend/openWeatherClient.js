// backend/src/openWeatherClient.js
const axios = require('axios');

const BASE_URL = 'https://api.openweathermap.org/data/2.5/weather';

class OpenWeatherClient {
  constructor(apiKey) {
    if (!apiKey) {
      throw new Error('OPENWEATHER_API_KEY is required');
    }
    this.apiKey = apiKey;
  }

  async fetchCurrentWeatherByCity(cityName) {
    const response = await axios.get(BASE_URL, {
      params: {
        q: cityName,
        appid: this.apiKey,
        units: 'metric'
      },
      timeout: 5000
    });

    return response.data;
  }
}

module.exports = OpenWeatherClient;
