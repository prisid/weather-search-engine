// backend/src/server.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const InMemoryCache = require('./cache');
const OpenWeatherClient = require('./openWeatherClient');

const app = express();

// ----- Config -----
const PORT = process.env.PORT || 4000;
const OPENWEATHER_API_KEY = process.env.OPENWEATHER_API_KEY;
const CACHE_TTL_MS = Number(process.env.CACHE_TTL_MS || 5 * 60 * 1000);
const CACHE_MAX_ENTRIES = Number(process.env.CACHE_MAX_ENTRIES || 100);

// ----- Dependencies -----
const cache = new InMemoryCache({
  ttlMs: CACHE_TTL_MS,
  maxEntries: CACHE_MAX_ENTRIES
});

const weatherClient = new OpenWeatherClient(OPENWEATHER_API_KEY);

// ----- Middleware -----
app.use(cors());
app.use(express.json());

// Serve frontend static files
const frontendPath = path.join(__dirname, '..', '..', 'frontend');
app.use(express.static(frontendPath));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    time: new Date().toISOString(),
    cacheEntries: cache.size()
  });
});

app.get('/api/weather', async (req, res) => {
  const city = (req.query.city || '').trim();

  if (!city) {
    return res.status(400).json({ error: 'Query parameter "city" is required.' });
  }

  const cacheKey = city.toLowerCase();

  const cached = cache.get(cacheKey);
  if (cached) {
    return res.json({ source: 'cache', ...cached });
  }

  try {
    const data = await weatherClient.fetchCurrentWeatherByCity(city);

    const transformed = {
      city: data.name,
      country: data.sys?.country,
      coordinates: {
        lat: data.coord?.lat,
        lon: data.coord?.lon
      },
      temperature: {
        current: data.main?.temp,
        feelsLike: data.main?.feels_like,
        min: data.main?.temp_min,
        max: data.main?.temp_max
      },
      humidity: data.main?.humidity,
      pressure: data.main?.pressure,
      visibility: data.visibility,
      wind: {
        speed: data.wind?.speed,
        deg: data.wind?.deg,
        gust: data.wind?.gust
      },
      clouds: data.clouds?.all,
      description: data.weather?.[0]?.description,
      icon: data.weather?.[0]?.icon,
      sunrise: data.sys?.sunrise
        ? new Date(data.sys.sunrise * 1000).toISOString()
        : null,
      sunset: data.sys?.sunset
        ? new Date(data.sys.sunset * 1000).toISOString()
        : null,
      raw: data
    };

    cache.set(cacheKey, transformed);

    res.json({ source: 'live', ...transformed });
  } catch (error) {
    console.error('Error fetching weather:', error.response?.data || error.message);

    if (error.response) {
      const status = error.response.status;
      const message = error.response.data?.message || 'Error from weather provider';
      return res.status(status).json({ error: message, providerStatus: status });
    }

    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('*', (req, res) => {
  res.sendFile(path.join(frontendPath, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Weather backend listening at http://localhost:${PORT}`);
});
